#### Java Map Interface :-

* A map contains values on the basis of key, i.e. key and value pair. Each key and value pair is known as an 	           entry. A Map contains unique keys.
* A Map is useful if you have to search, update or delete elements on the basis of a key.
* map has three classes: Hashtable,HashMap,LinkedHashMap.and Sorted map is interface.sorted map has TreeMap 		   	 method. 
---------------------------------------------------------------------------------------------------------------------
### Hashtable :-
* HashMap is Asychronous.
* This means if it’s used in multithread environment then more than one thread can access and process the HashMap    	simultaneously.
* 
