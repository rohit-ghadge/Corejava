### JDK :-java development kit-

	:---------------------------------------------------------------------:
	:                                                                     :
	:  :------------------------------------: :-----------------------:   :                :
	:  :   :-------: :-----------------:    : :  Development Tooles   :   :
	:  :   :  JVM  : :Libraey classes: :    : ::javac (Compiler)      :   :
	:  :   :-------: :-----------------:    : ::java  (Interpreter)   :   :
	:  :------------------------------------: :-----------------------:   :
	:                 JRE                                                 :
	:---------------------------------------------------------------------:
                                     JDK
-----------------------------------------------------------------------------------------------------------------------
 *  If we want to deploy/install java application then we must install JRE software on client's machine.

 *  java uses the compiler as well as Interpreter. How?
 *  The Compiler of java called as javac converts source code into an Intermediate file known as Bytecode file.
 *  The Bytecode file is unique for all types of OS means bytecode is platform-independent.
 *  The Interpreter of java (java) converts Bytecode into the specific OS-compatible machine code. This code will vary
    according to OS.
 
 *  Why we use both — Compiler as well as Interpreter in Java(Need of Separate compiler and Interpreter):-
 *  At the time of C and C++, only Compiler was there that converts source code into specific OS machine code. The
    machine code was OS dependent that varied from OS to OS.
 *  The problem the programmer was facing that They had to design a different compiler for different Operating System
    that is too difficult, Too time-consuming and much Costly.
 *  Then Sun Microsystem take the whole Initiative by making a Unique compiler that produces Platform Independent
    Bytecodes and the Specific JVM(Java Virtual Machine)or Interpreter that converts bytecodes into machine code that
    will vary from OS to OS.

 * JVM :-class load subsystam.
 *     1 Class Loader :-
             Demo.class file load into memory area.
          I-Boostrap class loader:-
         II-Extention class loader:-
        III-Application class loader:-  
      
      2 linking
                -varify 
                        -bytecode varify.
                -prepared 
                        -class level data ex static data load into the memory area.
                -resolved.
                        -symbolic referance raplaced by original referance.

      3 initilization.
                    -static block execution start.
----------------------------------------------------------------------------------------------------------------------
       -JVM memory:-
         -.class file load into the memory area of the jvm.it is common in all thread.

	  2-Memory Area:-class level data is store here and static variable store here.
       
       3-Heap:-object data(instance data).array store here. this memory is common and shared among the all thread.
       
       4:-Jvm language stack:-local variable save. for each thread it is diffrant stack frame. when method is called
       then stack frame is created then after excution complete stack is clear.
          
       5:-Pc register:-PC register store the address of the Java virtual machine instruction which is currently
 		executing. In Java, each thread has its separate PC register. 
     
       6:-native method Area:-it contain the all the native method.

-----------------------------------------------------------------------------------------------------------------------
      Execution engine :-
            -Interpreter:-
                  -The Interpreter of java (java) converts Bytecode into the specific OS-compatible machine code.
                  -it takes the single line of the code/instruction at a time.it do execution line by line.so it 
                  -slower than compiler. it takes less memory.dispay error line by line.

                  -jvm convert the bytecode line by line into machine code language and whichever line get converted
                  -into the machine language computer just run it.
            -JII compiler:-	
                 1 -Some portion of the bytecode is very critical.computer keepes on executing these bytecode 
                   -instruction again and again repeatedly for most the execution time.
                   
                   -why not converting the bytecode for all these critical portions just onces and use this already
                   -converted code next time when computer executes the same portion of bytecode.

			  2 - programmer may make silly mistake in the program they write and because of that the program
                     run on any computer.so jvm shoud optimise the bytecode before converting them into machine
                     language for the perticuar computer.
                 
              -Garbage collecter:-
              -Security manager :-
-----------------------------------------------------------------------------------------------------------------------
      Native Method Interface :-
              - The Native Method Interface is a programming framework. It allows Java code which is
              - running in a JVM to call by libraries and native applications. 

----------------------------------------------------------------------------------------------------------------------
      Native Method Libraries :-
                               Native Libraries is a collection of the Native Libraries(C, C++) which are needed by
                               the Execution Engine.
----------------------------------------------------------------------------------------------------------------------
   

